// ─── Service Worker Registration ───────────────────────────────────────────
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('./sw.js').catch(e => console.warn('SW reg failed:', e));
}

// ─── Offline / Online banner ────────────────────────────────────────────────
function showBanner(msg, color) {
  let b = document.getElementById('offlineBanner');
  if (!b) return;
  b.textContent = msg;
  b.style.background = color;
  b.style.display = 'block';
  if (color === '#22c55e') setTimeout(() => b.style.display='none', 3000);
}
window.addEventListener('offline', () => showBanner('⚠️ You are offline — showing cached data', '#b45309'));
window.addEventListener('online',  () => showBanner('✅ Back online — data is live', '#22c55e'));

// ─── Fallback static prices (updated periodically — used when fully offline with no cache) ──
const FALLBACK_PRICES = {
  bitcoin:      { usd: 83000,    usd_24h_change:  1.2  },
  ethereum:     { usd: 1580,     usd_24h_change: -0.8  },
  solana:       { usd: 130,      usd_24h_change:  2.1  },
  cardano:      { usd: 0.62,     usd_24h_change: -1.3  },
  dogecoin:     { usd: 0.155,    usd_24h_change:  0.5  },
  litecoin:     { usd: 78,       usd_24h_change: -0.3  },
  polkadot:     { usd: 4.2,      usd_24h_change:  1.0  },
  ripple:       { usd: 2.1,      usd_24h_change:  0.7  },
  binancecoin:  { usd: 580,      usd_24h_change: -0.4  },
  chainlink:    { usd: 12.5,     usd_24h_change:  1.8  },
  'avalanche-2':{ usd: 19,       usd_24h_change: -1.1  },
  'shiba-inu':  { usd: 0.0000122,usd_24h_change:  0.9  }
};

// Generate synthetic 24h price history from a single price point (for offline prediction)
function generateFallbackHistory(price) {
  const points = 288; // ~5-min intervals over 24h
  const now = Date.now();
  const start = now - 24 * 60 * 60 * 1000;
  const interval = (now - start) / points;
  let prices = [];
  let p = price * 0.98; // start slightly lower
  for (let i = 0; i <= points; i++) {
    p += (Math.random() - 0.495) * price * 0.001; // tiny random walk
    prices.push([start + interval * i, Math.max(p, price * 0.9)]);
  }
  return { prices };
}

// ─── Auth ───────────────────────────────────────────────────────────────────
function login()  { window.location.href = 'dashboard.html'; }
function logout() { window.location.href = 'index.html'; }

// ─── Coins list ─────────────────────────────────────────────────────────────
const coins = ['bitcoin','ethereum','solana','cardano','dogecoin','litecoin',
               'polkadot','ripple','binancecoin','chainlink','avalanche-2','shiba-inu'];

// ─── Fetch with retry + offline fallback ────────────────────────────────────
async function fetchWithRetry(url, retries=3, delay=1500) {
  for (let i = 0; i < retries; i++) {
    try {
      let res = await fetch(url);
      if (res.status === 429) { await sleep(delay*(i+1)); continue; }
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return await res.json();
    } catch(e) {
      if (i === retries-1) throw e;
      await sleep(delay);
    }
  }
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

// ─── localStorage helpers ────────────────────────────────────────────────────
function saveToCache(key, data) {
  try { localStorage.setItem(key, JSON.stringify({ ts: Date.now(), data })); } catch(e){}
}
function loadFromCache(key) {
  try {
    let raw = localStorage.getItem(key);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch(e) { return null; }
}

// ─── Dashboard: load prices ──────────────────────────────────────────────────
async function loadPrices() {
  let body = document.getElementById('cryptoTableBody');
  if (!body) return;
  body.innerHTML = `<tr><td colspan="4" style="text-align:center;color:#94a3b8;">Loading prices...</td></tr>`;

  let priceData = null;
  let source = 'live';

  try {
    let ids = coins.join(',');
    priceData = await fetchWithRetry(
      `https://api.coingecko.com/api/v3/simple/price?ids=${ids}&vs_currencies=usd&include_24hr_change=true&include_last_updated_at=true`
    );
    saveToCache('cryptoPrices', priceData);
  } catch(e) {
    // Try localStorage cache first
    let cached = loadFromCache('cryptoPrices');
    if (cached) {
      priceData = cached.data;
      source = 'cached';
      let ago = Math.round((Date.now() - cached.ts) / 60000);
      showBanner(`📦 Offline — showing prices cached ${ago} min ago`, '#b45309');
    } else {
      // Last resort: use hardcoded fallback
      priceData = FALLBACK_PRICES;
      source = 'fallback';
      showBanner('📦 Offline — showing approximate fallback prices', '#b45309');
    }
  }

  body.innerHTML = '';
  for (let coin of coins) {
    let d = priceData[coin];
    if (!d) { body.innerHTML += `<tr><td>${coin}</td><td colspan="3" style="color:#94a3b8;">N/A</td></tr>`; continue; }
    let change = d.usd_24h_change || 0;
    let updated = source === 'live' && d.last_updated_at
      ? new Date(d.last_updated_at*1000).toLocaleTimeString()
      : source === 'cached' ? '(cached)' : '(offline estimate)';
    body.innerHTML += `<tr>
      <td>${coin.charAt(0).toUpperCase()+coin.slice(1)}</td>
      <td>$${d.usd.toLocaleString()}</td>
      <td style="color:${change>=0?'#22c55e':'#ef4444'}">${change.toFixed(2)}%</td>
      <td style="color:#94a3b8;font-size:0.85em;">${updated}</td>
    </tr>`;
  }
}

// ─── Dashboard: load chart ───────────────────────────────────────────────────
async function loadChart() {
  let canvas = document.getElementById('cryptoChart');
  if (!canvas) return;

  let priceData = null;
  try {
    let topCoins = coins.slice(0,5);
    let ids = topCoins.join(',');
    priceData = await fetchWithRetry(
      `https://api.coingecko.com/api/v3/simple/price?ids=${ids}&vs_currencies=usd`
    );
    saveToCache('cryptoChart', priceData);
  } catch(e) {
    let cached = loadFromCache('cryptoChart');
    priceData = cached ? cached.data : null;
  }

  // If still no data, build from FALLBACK_PRICES
  if (!priceData) {
    priceData = {};
    coins.slice(0,5).forEach(c => { priceData[c] = { usd: FALLBACK_PRICES[c]?.usd || 0 }; });
  }

  let labels = [], prices = [];
  coins.slice(0,5).forEach(c => {
    labels.push(c.charAt(0).toUpperCase()+c.slice(1));
    prices.push(priceData[c]?.usd || 0);
  });

  new Chart(canvas, {
    type: 'bar',
    data: { labels, datasets: [{ label:'Price (USD)', data: prices, backgroundColor:'#38bdf8aa', borderColor:'#38bdf8', borderWidth:2 }]},
    options: {
      plugins: { legend: { labels: { color:'#e2e8f0' }}},
      scales: {
        x: { ticks: { color:'#e2e8f0' }, grid: { color:'#1e293b' }},
        y: { ticks: { color:'#e2e8f0' }, grid: { color:'#334155' }}
      }
    }
  });
}

// ─── Linear regression ───────────────────────────────────────────────────────
function linearRegression(x, y) {
  let n=x.length, sumX=0, sumY=0, sumXY=0, sumXX=0;
  for (let i=0;i<n;i++) { sumX+=x[i]; sumY+=y[i]; sumXY+=x[i]*y[i]; sumXX+=x[i]*x[i]; }
  let denom = n*sumXX - sumX*sumX;
  if (denom===0) return { slope:0, intercept: sumY/n };
  return { slope:(n*sumXY-sumX*sumY)/denom, intercept:(sumY-sumX*(n*sumXY-sumX*sumY)/denom)/n };
}

// ─── Predict ─────────────────────────────────────────────────────────────────
async function predict() {
  let resultEl   = document.getElementById('result');
  let tableWrap  = document.getElementById('predictionTableWrap');
  let tableBody  = document.getElementById('predictionTableBody');
  let coin       = document.getElementById('coin').value;
  let steps      = parseInt(document.getElementById('steps').value);

  if (!steps || steps<1 || steps>100) {
    resultEl.innerHTML = '<p style="color:#ef4444;">⚠️ Please enter a valid number of steps (1–100).</p>';
    if (tableWrap) tableWrap.style.display = 'none';
    return;
  }

  resultEl.innerHTML = '<p style="color:#94a3b8;">⏳ Fetching market data...</p>';
  if (tableWrap) tableWrap.style.display = 'none';

  let histData = null;
  let dataSource = 'live';

  try {
    histData = await fetchWithRetry(
      `https://api.coingecko.com/api/v3/coins/${coin}/market_chart?vs_currency=usd&days=1`
    );
    saveToCache(`chart_${coin}`, histData);
  } catch(e) {
    // Try localStorage cache
    let cached = loadFromCache(`chart_${coin}`);
    if (cached) {
      histData = cached.data;
      dataSource = 'cached';
    } else {
      // Generate synthetic history from fallback price
      let fallbackPrice = FALLBACK_PRICES[coin]?.usd || 100;
      histData = generateFallbackHistory(fallbackPrice);
      dataSource = 'fallback';
    }
  }

  if (!histData.prices || histData.prices.length < 2) {
    resultEl.innerHTML = '<p style="color:#ef4444;">⚠️ Not enough data to predict.</p>';
    return;
  }

  let x=[], y=[];
  histData.prices.forEach((p,i) => { x.push(i); y.push(p[1]); });

  let totalMs    = histData.prices[histData.prices.length-1][0] - histData.prices[0][0];
  let intervalMs = totalMs / (histData.prices.length - 1);
  let intervalMin = Math.round(intervalMs / 60000) || 5;

  let m = linearRegression(x, y);
  let currentPrice    = y[y.length-1];
  let lastTimestamp   = histData.prices[histData.prices.length-1][0];
  let coinName        = coin.charAt(0).toUpperCase()+coin.slice(1);

  let sourceNote = dataSource==='live' ? '' :
    dataSource==='cached' ? ' <span style="color:#f59e0b;font-size:0.8em;">(cached data)</span>' :
    ' <span style="color:#f59e0b;font-size:0.8em;">(offline estimate)</span>';

  resultEl.innerHTML = `<p style="color:#38bdf8;font-weight:bold;">
    📈 ${coinName} — ${steps} Step Prediction${sourceNote}<br>
    <span style="font-size:0.9em;color:#cbd5e1;">Current price: $${currentPrice.toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:6})}</span>
  </p>`;

  tableBody.innerHTML = '';
  for (let i=1; i<=steps; i++) {
    let predicted  = m.slope*(x.length+i)+m.intercept;
    let change     = predicted - currentPrice;
    let pct        = (change / currentPrice) * 100;
    let futureTime = new Date(lastTimestamp + intervalMs*i);
    let timeStr    = futureTime.toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'});
    let dateStr    = futureTime.toLocaleDateString([], {month:'short', day:'numeric'});
    let isUp       = change >= 0;
    let color      = isUp ? '#22c55e' : '#ef4444';
    let arrow      = isUp ? '▲' : '▼';

    tableBody.innerHTML += `<tr>
      <td>${i}</td>
      <td>${dateStr} ${timeStr}<br><span style="color:#94a3b8;font-size:0.8em;">+${i*intervalMin} min</span></td>
      <td style="font-weight:bold;">$${predicted.toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:6})}</td>
      <td style="color:${color};">${isUp?'+':''}$${change.toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:6})}</td>
      <td style="color:${color};font-weight:bold;">${arrow} ${Math.abs(pct).toFixed(2)}%</td>
      <td style="color:${color};font-size:1.2em;">${isUp?'📈':'📉'}</td>
    </tr>`;
  }

  if (tableWrap) tableWrap.style.display = 'block';
}
