const CACHE_NAME = 'cryptovision-v1';
const ASSETS = [
  './',
  './index.html',
  './dashboard.html',
  './predict.html',
  './about.html',
  './script.js',
  './style.css',
  'https://cdn.jsdelivr.net/npm/chart.js'
];

// Install: cache all core assets
self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(ASSETS)).then(() => self.skipWaiting())
  );
});

// Activate: remove old caches
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

// Fetch: network-first for API calls, cache-first for assets
self.addEventListener('fetch', e => {
  const url = e.request.url;

  // For CoinGecko API: try network, fall back to cached response if offline
  if (url.includes('coingecko.com')) {
    e.respondWith(
      fetch(e.request)
        .then(res => {
          // Clone and store successful API responses in cache
          let copy = res.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(e.request, copy));
          return res;
        })
        .catch(() => caches.match(e.request))
    );
    return;
  }

  // For Unsplash images: try network, fall back to cache, ignore errors
  if (url.includes('unsplash.com')) {
    e.respondWith(
      fetch(e.request)
        .then(res => {
          let copy = res.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(e.request, copy));
          return res;
        })
        .catch(() => caches.match(e.request) || new Response('', {status: 404}))
    );
    return;
  }

  // For everything else: cache-first
  e.respondWith(
    caches.match(e.request).then(cached => cached || fetch(e.request).then(res => {
      let copy = res.clone();
      caches.open(CACHE_NAME).then(cache => cache.put(e.request, copy));
      return res;
    }))
  );
});
